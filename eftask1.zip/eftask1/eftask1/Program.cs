﻿using eftask1.Data;
using eftask1.Models;

namespace eftask1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AplicationDbContext db = new AplicationDbContext();
            var product = new Product()
            {
               
                Name = "prod1",
                Description = "this is prod1",
                price=200.0,
                rate=23
            };
            db.Products.Add(product);
            var category = new Category() { 
            
             name="cat1"
            };
            db.Categories.Add(category);
            db.SaveChanges();
        }
    }
}
