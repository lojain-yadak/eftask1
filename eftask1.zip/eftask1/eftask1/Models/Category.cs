﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eftask1.Models
{
    internal class Category
    {
        [Key]
        public int catid { get; set; }
        public string name { get; set; }
    }
}
